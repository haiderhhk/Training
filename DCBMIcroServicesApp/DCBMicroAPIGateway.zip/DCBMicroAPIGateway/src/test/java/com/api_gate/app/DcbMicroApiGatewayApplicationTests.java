package com.api_gate.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DcbMicroApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
