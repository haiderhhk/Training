package com.contact_micro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactMicroServiceApplication.class, args);
	}

}
