package com.contact_micro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
